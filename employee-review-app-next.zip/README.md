# Employee Review App (Next.js + Tailwind CSS)

This is a basic SSR-ready employee review app scaffolded using **Next.js** and **Tailwind CSS**.
